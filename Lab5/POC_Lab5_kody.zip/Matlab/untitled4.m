I = imread("../ObrazySzare/Ex1.png");


I1 = HistogramStretch(I, "No Cut");


