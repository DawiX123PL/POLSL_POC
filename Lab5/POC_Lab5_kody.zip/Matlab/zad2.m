%clear all
close all
clc




source = [...
            "../ObrazySzare/Ex1.png", ...
            "../ObrazySzare/Ex2.png", ...
            "../ObrazySzare/Ex3.png", ...
            "../ObrazySzare/M92.png", ...
        ];



for i = 1:length(source)
    ProduceImages(source(i), "../zad2/Local/I" + num2str(i), "LOCAL");
    ProduceImages(source(i), "../zad2/Clahe/I" + num2str(i), "CLAHE");
end








function ProduceImages(source, destination, select)

    I1 = imread(source);
    I1 = double(I1) ./ 255;
    

    if select ==  "LOCAL"
        I2 = HistogramStretch(I1, "Auto");
        %I3 = LocalContrastFix2(I1,7);
        I3 = LocalContrastFix(I1, [6 6], 0.001);
    elseif select ==  "CLAHE"
        I2 = adapthisteq(I1,'NumTiles',[8 8],'ClipLimit',0.005);
        I3 = adapthisteq(I1,'NumTiles',[8 8],'ClipLimit',0.01);
    end


    %figure; imshow(I1);
    %figure; imshow(I2);
    %figure; imshow(I3);

    figure; imhist(I1); H1 = gcf;
    figure; imhist(I2); H2 = gcf;
    figure; imhist(I3); H3 = gcf;

 
    K_calc = @(I) [ k1(I) k2(I) k3(I) k4(I)];
    
    K1 = K_calc(I1);
    K2 = K_calc(I2);
    K3 = K_calc(I3);
    K  = [K1; K2; K3];
    
    
    minmax_calc = @(I) [ min(I,[],"all"), max(I,[],"all") ];
    
    M1 = minmax_calc(I1);
    M2 = minmax_calc(I2);
    M3 = minmax_calc(I3);
    M  = [M1; M2; M3];
    
    % zapis do plikow
    mkdir(destination);

    crop = [.12 .12 .12 .12];

    if select ==  "LOCAL"
        imwrite(cropImage(I1, crop), destination + "/I_Origin.png");
        imwrite(cropImage(I2, crop), destination + "/I_Global.png");
        imwrite(cropImage(I3, crop), destination + "/I_LocalF.png");
        saveas(H1, destination + "/H_Origin.png");
        saveas(H2, destination + "/H_Global.png");
        saveas(H3, destination + "/H_LocalF.png");
    elseif select ==  "CLAHE"
        imwrite(cropImage(I1, crop), destination + "/I_Origin.png");
        imwrite(cropImage(I2, crop), destination + "/I_CLAHE1.png");
        imwrite(cropImage(I3, crop), destination + "/I_CLAHE2.png");
        saveas(H1, destination + "/H_Origin.png");
        saveas(H2, destination + "/H_CLAHE1.png");
        saveas(H3, destination + "/H_CLAHE2.png");
    end

    close([H1 H2 H3])

    data1 = "k1 = "           + num2str(K1(1), 5) ...
          + " \\\\ k2 = "     + num2str(K1(2), 5) ...
          + " \\\\ k3 = "     + num2str(K1(3), 5) ...
          + " \\\\ k4 = "     + num2str(K1(4), 5) ...
          + " \\\\ min(I) = " + num2str(M1(1), 5) ...
          + " \\\\ max(I) = " + num2str(M1(2), 5) + " \n";

    data2 = "k1 = "           + num2str(K2(1), 5) ...
          + " \\\\ k2 = "     + num2str(K2(2), 5) ...
          + " \\\\ k3 = "     + num2str(K2(3), 5) ...
          + " \\\\ k4 = "     + num2str(K2(4), 5) ...
          + " \\\\ min(I) = " + num2str(M2(1), 5) ...
          + " \\\\ max(I) = " + num2str(M2(2), 5) + " \n";

    data3 = "k1 = "           + num2str(K3(1), 5) ...
          + " \\\\ k2 = "     + num2str(K3(2), 5) ...
          + " \\\\ k3 = "     + num2str(K3(3), 5) ...
          + " \\\\ k4 = "     + num2str(K3(4), 5) ...
          + " \\\\ min(I) = " + num2str(M3(1), 5) ...
          + " \\\\ max(I) = " + num2str(M3(2), 5) + " \n";
         
    data = data1 + data2 + data3;

    disp(data);
    
    fid = fopen(destination + "/result",'w');
    fprintf(fid, data);
    fclose(fid);



end